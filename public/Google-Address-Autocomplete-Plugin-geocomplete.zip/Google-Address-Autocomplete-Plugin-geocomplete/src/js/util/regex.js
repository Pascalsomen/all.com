const SPACES = /\s+/g
const SPACES_AND_UNDERSCORES = /\s+|_+/g

export { SPACES, SPACES_AND_UNDERSCORES }
