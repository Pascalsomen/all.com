const logError = function(msg) {
  /* eslint-disable no-console */
  console.error(msg)
}

export { logError }
