const $ = window.jquery || window.$

export { $ }
